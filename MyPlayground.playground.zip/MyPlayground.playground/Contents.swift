import Darwin
import CoreText
// task1
//
//
class Shape{
    func area()  -> Double {
        return 0
    }
    func volume() -> Double {
        return 0
    }
}

class Circle: Shape {
    
    var radius: Double
    init(radius: Double) {
        self.radius = radius
        super.init()
    }
    
    override func area() -> Double {
        return Double.pi * radius * radius
    }
    override func volume() -> Double { return 0
        
    }
}

class Triangle: Shape {
    var base: Double = 6
    var heght: Double = 7
    
    init(base: Double , heght: Double){
        self.base = base
        self.heght = heght
        
        super.init()
    }
}

class square:Shape {
    var Length:Double = 4
    override func area() -> Double {
        return Length*Length
    }
    override func volume() -> Double {
        return Length*3
        
    }
}
// task2
//
//
struct Book {
    var title:String = ""
    var auther: String = ""
    var pages: Int = 0
    var price: Double = 0.0
    
    
}

//task3
//
//

var favorriteBook = Book()
print(favorriteBook.title)

favorriteBook.title = "peaple"
favorriteBook.auther = "hassen"
favorriteBook.pages = 100
favorriteBook.price = 75

print("the title book / (favoriteBook.title")

// task4
//
//
class elemnts {
    var number = [1,2,3,4,5,6,]
    func max ()-> Int {
        return number.max() ?? 0
    }
    func min ()-> Int {
        return number.min() ?? 0
    }
    func total ()-> Int{
        return number.reduce(0, +)
        
    }
    
}

// task5
//
//
class Distance {
    var feet : Int
    var inch : Int
    init(feet: Int , inch: Int) {
        self.feet = feet
        self.inch = inch
    }
    func format() {
        print(feet)
    }
    var fee = Distance(feet: 0 , inch: 0)
    var Inch = Distance(feet: 11 , inch: 23)
    
    
    
    
    
    
    
    
    
    
    
    
}















